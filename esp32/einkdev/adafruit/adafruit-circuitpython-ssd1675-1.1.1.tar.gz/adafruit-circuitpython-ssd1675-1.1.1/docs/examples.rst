Simple test
------------

Ensure your monochrome featherwing works with this simple test.

.. literalinclude:: ../examples/ssd1675_simpletest.py
    :caption: examples/ssd1675_simpletest.py
    :linenos:

2.13" Monochrome
-----------------

Ensure your 2.13" Monochrome breakout works with this simple test.

.. literalinclude:: ../examples/ssd1675_2.13_monochrome.py
    :caption: examples/ssd1675_2.13_monochrome.py
    :linenos:
