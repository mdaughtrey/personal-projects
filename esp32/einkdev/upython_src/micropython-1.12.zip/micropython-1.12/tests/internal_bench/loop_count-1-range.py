import bench

def test(num):
    for i in range(num):
        pass

bench.run(test)
