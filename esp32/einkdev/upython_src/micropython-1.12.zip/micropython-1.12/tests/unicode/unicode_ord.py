# test builtin ord with unicode characters

print(ord('α'))
