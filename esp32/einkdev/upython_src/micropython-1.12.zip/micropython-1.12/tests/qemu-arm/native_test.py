import native_frozen_align

native_frozen_align.native_x(1)
native_frozen_align.native_y(2)
native_frozen_align.native_z(3)
