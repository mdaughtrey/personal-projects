# uPy and CPython outputs differ for the following
print("%.1g" % -9.9) # round up 'g' with '-' sign
print("%.2g" % 99.9) # round up
