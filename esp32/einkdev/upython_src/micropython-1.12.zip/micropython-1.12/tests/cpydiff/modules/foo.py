print('foo')
xxx
