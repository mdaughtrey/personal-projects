"""
categories: Modules,array
description: Looking for integer not implemented
cause: Unknown
workaround: Unknown
"""
import array
print(1 in array.array('B', b'12'))
