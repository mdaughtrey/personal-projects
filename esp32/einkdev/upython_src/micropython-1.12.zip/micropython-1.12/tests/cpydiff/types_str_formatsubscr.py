"""
categories: Types,str
description: Attributes/subscr not implemented
cause: Unknown
workaround: Unknown
"""
print('{a[0]}'.format(a=[1, 2]))
