"""
categories: Types,str
description: Start/end indices such as str.endswith(s, start) not implemented
cause: Unknown
workaround: Unknown
"""
print('abc'.endswith('c', 1))
