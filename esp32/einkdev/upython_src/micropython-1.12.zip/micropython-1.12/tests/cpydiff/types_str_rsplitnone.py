"""
categories: Types,str
description: None as first argument for rsplit such as str.rsplit(None, n) not implemented
cause: Unknown
workaround: Unknown
"""
print('a a a'.rsplit(None, 1))
