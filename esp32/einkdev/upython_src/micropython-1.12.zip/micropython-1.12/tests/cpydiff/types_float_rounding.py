"""
categories: Types,float
description: uPy and CPython outputs formats may differ
cause: Unknown
workaround: Unknown
"""
print('%.1g' % -9.9)
