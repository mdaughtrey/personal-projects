"""
categories: Syntax,Unicode
description: Unicode name escapes are not implemented
cause: Unknown
workaround: Unknown
"""
print("\N{LATIN SMALL LETTER A}")
