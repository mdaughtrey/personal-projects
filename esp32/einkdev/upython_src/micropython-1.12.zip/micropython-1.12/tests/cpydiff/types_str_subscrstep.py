"""
categories: Types,str
description: Subscript with step != 1 is not yet implemented
cause: Unknown
workaround: Unknown
"""
print('abcdefghi'[0:9:2])
