"""
categories: Types,tuple
description: Tuple load with step != 1 not implemented
cause: Unknown
workaround: Unknown
"""
print((1, 2, 3, 4)[0:4:2])
