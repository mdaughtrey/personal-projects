try:
    import uio
    print("uio")
except ImportError:
    print("no")
