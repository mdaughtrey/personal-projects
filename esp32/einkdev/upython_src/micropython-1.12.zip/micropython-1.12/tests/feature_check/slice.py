try:
    slice
    print("slice")
except NameError:
    print("no")
