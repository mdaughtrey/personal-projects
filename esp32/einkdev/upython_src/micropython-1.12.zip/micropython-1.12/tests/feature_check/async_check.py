# check if async/await keywords are supported
async def foo():
    await 1
