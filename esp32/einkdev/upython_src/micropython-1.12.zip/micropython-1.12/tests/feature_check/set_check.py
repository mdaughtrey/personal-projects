# check if set literal syntax is supported
{1}
