# Check whether arbitrary-precision integers (MPZ) are supported
print(1000000000000000000000000000000000000000000000)
