try:
    bytearray
    print("bytearray")
except NameError:
    print("no")
