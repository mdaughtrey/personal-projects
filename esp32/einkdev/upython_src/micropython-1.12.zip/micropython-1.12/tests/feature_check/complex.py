try:
    complex
    print("complex")
except NameError:
    print("no")

