try:
    extra_coverage
    print('coverage')
except NameError:
    print('no')
