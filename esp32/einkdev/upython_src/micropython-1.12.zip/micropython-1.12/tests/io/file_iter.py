f = open("io/data/file1")
for l in f:
    print(l)
