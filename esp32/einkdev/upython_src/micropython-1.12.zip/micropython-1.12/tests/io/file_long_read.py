f = open("io/data/file1")
b = f.read(100)
print(len(b))
