import sys

print(sys.stdin.fileno())
print(sys.stdout.fileno())
