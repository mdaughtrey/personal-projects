f = open("io/data/bigfile1")
b = f.read()
print(len(b))
print(b)
