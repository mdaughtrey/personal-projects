#include <iostream>
#include <iomanip>

extern "C"
{
#include <usb.h>
}

#include <usbdriver.h>

using namespace std;
#define USB_TIMEOUT 500

usb_dev_handle * hTinyISP;


usb_dev_handle * acquireTinyISP(void)
{
  struct usb_bus * thisBus;
  struct usb_device * thisDevice = NULL;

  usb_init();
  usb_find_busses();
  usb_find_devices();

  for (int retry = 0; retry < 1 && NULL == thisDevice; retry++)
    {

      for (thisBus = usb_get_busses(); NULL != thisBus; thisBus = thisBus->next)
	{
	  
	  for (thisDevice = thisBus->devices; NULL != thisDevice; thisDevice = thisDevice->next)
	    {
	      usb_dev_handle * device;
	      device = usb_open(thisDevice);
	      cout << "Vendor " << hex << setw(4) << setfill('0')
		   << thisDevice->descriptor.idVendor
		   << " Product " << thisDevice->descriptor.idProduct
		   << endl;
  

	      if (TINYISP_VENDORID == thisDevice->descriptor.idVendor &&
		  TINYISP_PRODUCTID == thisDevice->descriptor.idProduct)
		{
		  cout << "Acquired device" << endl;
		  return device;
		}
	      usb_close(device);
	      
	    }
	}
      cerr << "No device found, sleeping..." << endl;
      sleep(1);
    }
}

void usb_control ( int req, int val, int size )
{
  usb_control_msg( hTinyISP,
		   USB_ENDPOINT_IN | USB_TYPE_VENDOR | USB_RECIP_DEVICE,
		   req, val, size, NULL, 0, USB_TIMEOUT );
}

void dataToDisplay(string data)
{
  cout << "Display " << data.c_str() << endl;

      usb_control(USBTINY_CLR, 1, 1); // /SS low
  for (string::iterator iData = data.begin();
       iData != data.end();
       iData++)
    {
      usb_control(USBTINY_SPI1, *iData,  1);	// data
    }
      usb_control(USBTINY_SET, 1, 1); // /SS high
}

int main(int argc, char ** argv)
{
  //  struct usb_bus * busses;

  hTinyISP = acquireTinyISP();

  if (NULL == hTinyISP)
    {
      cerr << "Could not acquire device" << endl;
      exit(1);
    }

//   usb_control( USBTINY_POWERUP, USB_TIMEOUT, RESET_HIGH );
   usb_control( USBTINY_POWERUP, USB_TIMEOUT, RESET_LOW );
   sleep(1);
   usb_control( USBTINY_POWERUP, USB_TIMEOUT, RESET_HIGH );
   sleep(1);

  //
  // Set PB1 to output for ~Slave Select
  // 1011 0010
  //
  usb_control(USBTINY_DDRWRITE, 0xb2, 1);

  usb_control(USBTINY_SET, 1, 1); // /SS high

  dataToDisplay(argv[1]);
  usb_control( USBTINY_POWERDOWN, 0, 0 );
  usb_close(hTinyISP);


  
}
